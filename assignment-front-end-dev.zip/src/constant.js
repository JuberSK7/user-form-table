const Cities = [
    { value: "Mumbai", label: "Mumbai" },
    { value: "Pune", label: "Pune" },
    { value: "Delhi", label: "Delhi" },
    { value: "Hydrabad", label: "Hydrabad" },
    { value: "Chennai", label: "Chennai" },
    { value: "Banglore", label: "Banglore" },
    { value: "Kolkatta", label: "Kolkatta" },
    { value: "Nagpur", label: "Nagpur" },
    { value: "Ahmadabad", label: "Ahmadabad" },
    { value: "Noida", label: "Noida" },
  ];

export default Cities