import './App.css';
import Personform from './component/Personform';


function App() {
  return (
    <div className="App">
      <Personform />
    </div>
  );
}

export default App;
